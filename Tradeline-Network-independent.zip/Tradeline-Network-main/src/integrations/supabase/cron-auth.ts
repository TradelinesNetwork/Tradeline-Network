// Guards a scheduled/cron-triggered endpoint. Previously this checked a
// secret (`LOVABLE_CRON_SECRET`) that Lovable's own job scheduler attached
// automatically. Since you're managing your own scheduling now (e.g. Vercel
// Cron), generate your own random secret and set it as `CRON_SECRET` in your
// Vercel project's environment variables. Whatever calls this endpoint on a
// schedule must send it as: Authorization: Bearer <CRON_SECRET>
//
// `CRON_SECRET_PREVIOUS` is optional — only set it temporarily while rotating
// to a new secret, so in-flight scheduled calls signed with the old one still
// pass during the changeover.
export async function authenticateCronRequest(
  request: Request,
): Promise<Response | null> {
  const currentSecret = process.env['CRON_SECRET']
  const previousSecret = process.env['CRON_SECRET_PREVIOUS']

  if (!currentSecret) {
    return new Response('Server configuration error', { status: 500 })
  }

  const match = /^Bearer ([^\s,]+)$/.exec(
    request.headers.get('authorization') ?? '',
  )
  const token = match?.[1]
  if (!token) {
    return new Response('Unauthorized', { status: 401 })
  }

  const { createHash, timingSafeEqual } = await import('node:crypto')
  const digest = (value: string) =>
    createHash('sha256').update(value, 'utf8').digest()
  const providedDigest = digest(token)
  const currentMatches = timingSafeEqual(providedDigest, digest(currentSecret))
  const previousMatches = timingSafeEqual(
    providedDigest,
    digest(previousSecret ?? currentSecret),
  )

  if (!currentMatches && !previousMatches) {
    return new Response('Unauthorized', { status: 401 })
  }

  return null
}
