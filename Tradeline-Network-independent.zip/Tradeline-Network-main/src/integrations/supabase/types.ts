export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      broker_applications: {
        Row: {
          business_name: string
          contact_name: string
          created_at: string
          email: string
          id: string
          monthly_volume: string | null
          notes: string | null
          phone: string | null
          reviewed_at: string | null
          status: string
          status_reason: string | null
          tier: string
          user_id: string | null
        }
        Insert: {
          business_name: string
          contact_name: string
          created_at?: string
          email: string
          id?: string
          monthly_volume?: string | null
          notes?: string | null
          phone?: string | null
          reviewed_at?: string | null
          status?: string
          status_reason?: string | null
          tier: string
          user_id?: string | null
        }
        Update: {
          business_name?: string
          contact_name?: string
          created_at?: string
          email?: string
          id?: string
          monthly_volume?: string | null
          notes?: string | null
          phone?: string | null
          reviewed_at?: string | null
          status?: string
          status_reason?: string | null
          tier?: string
          user_id?: string | null
        }
        Relationships: []
      }
      order_items: {
        Row: {
          au_ciphertext: string
          created_at: string
          id: string
          order_id: string
          tradeline_id: string
          tradeline_snapshot: Json
          user_id: string
        }
        Insert: {
          au_ciphertext: string
          created_at?: string
          id?: string
          order_id: string
          tradeline_id: string
          tradeline_snapshot: Json
          user_id: string
        }
        Update: {
          au_ciphertext?: string
          created_at?: string
          id?: string
          order_id?: string
          tradeline_id?: string
          tradeline_snapshot?: Json
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          account_age_years: number | null
          au_quantity: number | null
          bureau_reporting: string | null
          confirmation_email_sent_at: string | null
          created_at: string
          credit_limit: number | null
          crypto: string
          customer_email: string | null
          customer_name: string | null
          fees: number
          id: string
          merchant_address: string
          network: string
          payment_status: string
          price_per_spot: number | null
          status: string
          status_reason: string | null
          subtotal: number
          total: number
          tradeline_company: string | null
          tradeline_number: string | null
          tx_hash: string
          updated_at: string
          user_id: string
        }
        Insert: {
          account_age_years?: number | null
          au_quantity?: number | null
          bureau_reporting?: string | null
          confirmation_email_sent_at?: string | null
          created_at?: string
          credit_limit?: number | null
          crypto: string
          customer_email?: string | null
          customer_name?: string | null
          fees?: number
          id?: string
          merchant_address: string
          network: string
          payment_status?: string
          price_per_spot?: number | null
          status?: string
          status_reason?: string | null
          subtotal: number
          total: number
          tradeline_company?: string | null
          tradeline_number?: string | null
          tx_hash: string
          updated_at?: string
          user_id: string
        }
        Update: {
          account_age_years?: number | null
          au_quantity?: number | null
          bureau_reporting?: string | null
          confirmation_email_sent_at?: string | null
          created_at?: string
          credit_limit?: number | null
          crypto?: string
          customer_email?: string | null
          customer_name?: string | null
          fees?: number
          id?: string
          merchant_address?: string
          network?: string
          payment_status?: string
          price_per_spot?: number | null
          status?: string
          status_reason?: string | null
          subtotal?: number
          total?: number
          tradeline_company?: string | null
          tradeline_number?: string | null
          tx_hash?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string
          full_name: string
          id: string
          phone: string | null
          updated_at: string
          user_id: string
          welcome_email_sent_at: string | null
        }
        Insert: {
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          phone?: string | null
          updated_at?: string
          user_id: string
          welcome_email_sent_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          phone?: string | null
          updated_at?: string
          user_id?: string
          welcome_email_sent_at?: string | null
        }
        Relationships: []
      }
      seller_applications: {
        Row: {
          bank_name: string
          card_age_years: number | null
          card_limit: number | null
          created_at: string
          email: string
          full_name: string
          id: string
          notes: string | null
          phone: string | null
          reviewed_at: string | null
          status: string
          status_reason: string | null
          user_id: string | null
          utilization_pct: number | null
        }
        Insert: {
          bank_name: string
          card_age_years?: number | null
          card_limit?: number | null
          created_at?: string
          email: string
          full_name: string
          id?: string
          notes?: string | null
          phone?: string | null
          reviewed_at?: string | null
          status?: string
          status_reason?: string | null
          user_id?: string | null
          utilization_pct?: number | null
        }
        Update: {
          bank_name?: string
          card_age_years?: number | null
          card_limit?: number | null
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          notes?: string | null
          phone?: string | null
          reviewed_at?: string | null
          status?: string
          status_reason?: string | null
          user_id?: string | null
          utilization_pct?: number | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
    },
  },
} as const
