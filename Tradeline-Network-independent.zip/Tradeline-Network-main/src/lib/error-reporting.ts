// Replaces the old Lovable-specific error reporter. Previously this forwarded
// uncaught React errors to Lovable's dashboard via a `window.__lovableEvents`
// hook that Lovable's own script injected. That hook no longer exists once
// you're off Lovable, so this now just logs locally.
//
// If you want real production error tracking (recommended), this is the spot
// to wire up a service like Sentry — swap the console.error call below for
// e.g. Sentry.captureException(error, { extra: context }).

export function reportError(error: unknown, context: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;
  console.error("[app error]", error, {
    route: window.location.pathname,
    ...context,
  });
}
