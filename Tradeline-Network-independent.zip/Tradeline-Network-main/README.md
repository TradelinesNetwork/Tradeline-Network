# Tradelines Network

Marketplace app for browsing and purchasing authorized-user tradeline spots,
tracking orders, and managing your account.

## Stack

- [TanStack Start](https://tanstack.com/start) (React, file-based routing, SSR) + Vite
- [Supabase](https://supabase.com) — Postgres database, authentication, storage
- [Resend](https://resend.com) — transactional email (order confirmations, welcome emails)
- Tailwind CSS + shadcn/ui components
- Deployed on [Vercel](https://vercel.com)

## Getting started

Requires Node.js 20+.

```sh
npm install
cp .env.example .env   # then fill in the values below
npm run dev
```

### Environment variables

| Variable | Where it's used | Notes |
|---|---|---|
| `SUPABASE_URL` / `VITE_SUPABASE_URL` | client & server | Your Supabase project URL |
| `SUPABASE_PUBLISHABLE_KEY` / `VITE_SUPABASE_PUBLISHABLE_KEY` | client & server | Supabase anon/publishable key (safe to expose to the browser) |
| `SUPABASE_SERVICE_ROLE_KEY` | server only | Bypasses Row Level Security — never expose to the client |
| `RESEND_API_KEY` | server only | Used to send transactional emails via Resend |
| `RESEND_FROM` | server only | e.g. `Tradelines Network <no-reply@tradelinesnetwork.trade>` — the domain must be verified in Resend |
| `ORDER_PII_SECRET` | server only | Encryption key for order PII fields |
| `CRON_SECRET` | server only | Bearer token required by scheduled/cron-triggered endpoints, if any are enabled |

The static pages under `public/*.html` (account, order tracking, etc.) load
Supabase directly from `public/assets/js/tlm-auth.js`, which has the project
URL and publishable key hardcoded at the top of the file (it can't read
`.env` since it isn't built by Vite) — keep that file in sync with your
Supabase project's values.

## Project structure

```
src/
  routes/            # TanStack Start file-based routes (pages + API routes)
  integrations/
    supabase/         # Supabase client(s) + auth middleware
  lib/                # Shared server/client utilities (email, error reporting, etc.)
public/               # Static marketing/marketplace HTML pages + assets
supabase/migrations/  # SQL migrations for the Supabase database schema
```

## Scripts

```sh
npm run dev        # start the dev server
npm run build      # production build
npm run preview    # preview a production build locally
npm run lint        # eslint
npm run format      # prettier --write
```

## Deployment

Deployed on Vercel via GitHub — pushing to the connected branch triggers a
deploy. Environment variables are configured under Vercel's Project Settings
→ Environment Variables, not committed to the repo.
